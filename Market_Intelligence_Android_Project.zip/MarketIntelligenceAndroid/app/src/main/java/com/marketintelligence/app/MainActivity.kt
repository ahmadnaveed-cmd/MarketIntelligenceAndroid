package com.marketintelligence.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("market_intelligence", MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun getSavedApiKey(): String = prefs.getString("twelvedata_key", "") ?: ""

        @JavascriptInterface
        fun saveApiKey(key: String) {
            prefs.edit().putString("twelvedata_key", key.trim()).apply()
        }

        // Called on WebView's JavaScript bridge thread. API key stays in app-private storage.
        @JavascriptInterface
        fun fetchQuote(symbol: String): String {
            val key = getSavedApiKey()
            if (key.isBlank()) return JSONObject().put("error", "Add your Twelve Data API key in Settings.").toString()
            var conn: HttpURLConnection? = null
            return try {
                val encoded = java.net.URLEncoder.encode(symbol, "UTF-8")
                val url = URL("https://api.twelvedata.com/quote?symbol=$encoded&apikey=${java.net.URLEncoder.encode(key, "UTF-8")}")
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 12000
                    readTimeout = 12000
                }
                val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                    .bufferedReader().use { it.readText() }
                val obj = JSONObject(body)
                if (obj.has("code") || obj.has("status") && obj.optString("status") == "error") {
                    JSONObject().put("error", obj.optString("message", "Market data provider returned an error.")).toString()
                } else {
                    JSONObject()
                        .put("symbol", obj.optString("symbol", symbol))
                        .put("name", obj.optString("name", symbol))
                        .put("price", obj.optString("close", ""))
                        .put("change", obj.optString("change", ""))
                        .put("percent_change", obj.optString("percent_change", ""))
                        .put("timestamp", obj.optString("datetime", ""))
                        .toString()
                }
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "Unable to retrieve quote.").toString()
            } finally {
                conn?.disconnect()
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
